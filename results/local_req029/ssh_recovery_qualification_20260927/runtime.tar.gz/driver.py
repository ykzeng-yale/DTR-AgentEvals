import sys,time
sys.path.insert(0,'/Users/yukangzengcmac/DTR-AgentEvals/experiments/remote_req029')
from recovery_transport import Transport
t=Transport(*sys.argv[1:],role="controller",deadline=time.time()+30,alias="mac-mini",interval=0,fixture=True)
t.publish("request",{"inert":True},1)
