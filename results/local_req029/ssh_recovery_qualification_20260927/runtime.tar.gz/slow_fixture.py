import os,signal,time
signal.alarm(5)
open('/tmp/dtr-req029p-qualified.aEsHQ1vE/slow.pid','x').write(str(os.getpid()))
time.sleep(30)
