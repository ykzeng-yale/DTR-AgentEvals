# Revised experimental design: evaluation, adaptation and feedback

**21 September 2026 UTC design; current status reconciled 26 September. Prospective draft, not run authorization.** This replaces the future-design defaults in [v0.1](experiment_protocol.md); it does not retrospectively amend any archived experiment or CONFIRM outcome. The bounded DEVELOPMENT rules in AGENTS.md supersede the earlier blanket theory-host compute deferral. Current model/live/CONFIRM and synthetic-batch holds remain in the [latest handoff](experiment_handoff.md); historical requests below are not new releases. The [literature/code review](literature_design_review_20260921.md) supplies sources and implementation boundaries. Exact resource, task and analysis manifests must pass the gates below before future collection.

**26 September precision decision:** REQ-024 supplies reviewed prospective complete-block analysis code.
The [precision audit](theory_precision_design_20260926.md) shows that its range-only guarantees do not yet
give a feasible real-agent sample plan, even after tighter shared-score bounds. Independently executed fixed
task/family groups could preserve the target with a stronger independence contract; that alternative is
not frozen or empirically validated. Numerical half-width examples are not adopted scientific margins.

## 1. Scientific questions and possible negative conclusions

The current archive demonstrates execution feasibility but does not establish history-adaptive improvement: the learned repair rule is a fixed large/small/large schedule; visible feedback and late decision opportunities are limited; several uncertainty claims remain unresolved. More training or a larger model would not distinguish these explanations by itself.

| Question | Target and comparison | Evidence needed |
|---|---|---|
| E1: Is evaluation reliable and economical? | Values of frozen policies under a common harness; OPE versus exact truth in simulation and independent fresh policy executions in agents | Bias, error and interval calibration separately; uncertainty in the live reference; total acquisition cost for one policy and a policy catalog |
| E2: Does observed history improve allocation? | Frozen history-dependent router versus a prompt-only router with the same initial action, learner class and resources; also versus the strongest development-selected fixed schedule | Fresh root-to-terminal executions on untouched issues; prespecified success and resource comparisons, with multiplicity handled |
| E3: Are local continuation comparisons valid? | Restored-prefix continuation effects under a declared frame and execution model | Same-model restoration controls, complete state provenance and appropriate source/selection/execution inference; secondary, not required to launch E1/E2 |

Well-calibrated OPE can correctly report no useful adaptation. Good ranking need not imply accurate values. A fixed schedule winning limits the tested frozen router/class under this harness and precision; it does not rule out all useful history dependence. No significant difference is neither equivalence nor noninferiority. A failure of support is not cured by a richer outcome model.

## 2. Simulation design using known truth

Follow ADEMP: explicitly state aims, generator, target, methods and performance. Existing S1/E0 results remain historical; this design addresses additional fixed-task, opportunity and inference questions rather than relabeling those runs.

**Exact control before a larger generator.** After a common first call, draw latent repair type U with probability 1/2 and record F = U xor E, E Bernoulli(q) independently of U. At the repair decision A in {0,1}, draw a fresh terminal Bernoulli success with probability 1/2 + eta(2A−1)(2U−1); action 1 costs c. Each constant arm has success 1/2. The observable rule A=F has success 1/2+eta(1−2q), and utility gain over constant action 0 of eta(1−2q)−c/2. Use eta in {0,.2}, q in {0,.25,.5}, c=.1. These include positive, zero-information and unfavorable cost-adjusted controls. The U-observing oracle is unavailable to the learner. This is an analytic diagnostic, not an agent-performance model or a newly claimed theorem.

**21 September, 04:18 UTC control refinement:** retain the six original cells and add one separately labeled
cost-dominated informative cell, eta=.2, q=.4, c=.1. Here A=F has success .54, cost .05 and utility .49,
so its gain over constant 0 is -.01, while the best F-measurable policy is constant 0 and best-class advantage
is zero. The [lead review and independent enumeration](theory_feedback_20260921_exact_control.md) distinguish
this case from absent effect or uninformative feedback. Preserve the original six-cell artifact; this is a
prospective development diagnostic, not a change to the real-study utility or the 32-cell core grid.

**Finite repair generator.** Implement explicit transition/observation tables for task stratum, latent correctness/error type, observed tool feedback, previous action, retained error-memory bit and remaining opportunities. Actions affect future state and therefore feedback and later assignment. Keep terminal correctness distinct from visible pass; a false pass may trigger the declared stopping rule. Start with binary success and bounded costs. Derive policy truth twice: full-history enumeration and Bellman recursion on a demonstrably sufficient state, including beliefs/history when observations are insufficient. Require agreement within 1e−10 for each frozen policy and each outcome component. A large simulated reference mean is not exact truth.

**Planned compact core:** n fixed tasks in {250,1000}, maximum eligible opportunities K in {2,4}, known behavior floor in {.5,.2}, no versus observable action-effect crossing, informative versus weak feedback: 32 cells. Specify actual tables and exact best-fixed versus best-observed-history advantages before accepting the generator. Changing overlap must leave targets and transition/outcome kernels unchanged; changing feedback can change policy occupancy/value and must be reported. This grid is not yet a runnable manifest. Add separately labeled severe-overlap, zero-support, hidden assignment-confounding, non-Markov coarsening, false-pass stopping and execution-drift stress cells; do not multiply every stress into the core.

**21 September, 05:50 UTC kernel acceptance:** the [lead review](theory_feedback_20260921_repair_generator.md)
accepts the proposed finite tables as development kernels, retaining the no-crossing zero-advantage cells.
K counts repair decisions after a common initial small call. Eight core kernels crossed with two task counts
and two logger floors remain 32 core cells; four U-irrelevant kernels are auxiliary controls. The exact
observed-history optimum assumes known kernels and fixed stopping, not a learned policy or optimized stopping.
The first version has no retained error-memory bit or visible false negatives; non-Markov/coarsening stress
extensions, logging and complete fixed-task/branch sampling remain outstanding. Independent latent-mass
checks reproduce all 12 oracle values and 156 catalog values. This does not validate interval coverage.

**Two sampling layers, never pooled:**

1. Fixed benchmark: retain task identities across independent complete study repetitions, redraw complete assignment/execution blocks, and compute the target as a mean of task-specific expected values. An archive-matching branch module must reproduce eight episodes/task, initial 4/4 assignment, later known randomization, zero-prefix tasks, SRS prefix sampling and fresh continuations. Its pooled target is the [ratio of expected totals](theory_branch_fixed_benchmark_bound.md), not a mean of available task ratios or a selected realized-frame mean.
2. Population extension: redraw tasks from an explicit finite distribution and use its population target. Label this a distinct study. It cannot validate the archive by changing its sampling model.

**Methods:** per-decision IPW, the existing longitudinal DR implementation with known assignment probabilities, outcome regression alone, and direct on-policy evaluation. Add deliberately coarsened outcome fits and misspecified propensities as diagnostics, not production defaults. Keep zero-support and hidden-confounding cells outside identified-estimator claims. Copying outcomes and frozen-state replay are negative controls only in settings where they should fail; retain an appropriate replay positive control. Freeze policies externally for estimator calibration; refit the entire selection procedure within each repetition when studying policy selection. Keep task/family folds intact.

**Outcomes of each simulated study:** bias, MSE, interval coverage/length, inference/denominator failures, false improvement decisions, selected-policy regret, exact adaptive potential, opportunity occupancy and weight second moments. Report paired differences between methods with Monte Carlo uncertainty. Count a failed interval as noncoverage for the primary operating-characteristic summary unless the predeclared method returns a valid conservative fallback; also report failures separately. Do not hide failures by complete-case averaging.

Plan final nominal-95% coverage/type-I summaries with 2,000 independent complete repetitions: MCSE is about .0049 near .95/.05, but about .0112 near .5. If precision of .005 is required uniformly, use 10,000, subject to a separately approved compute plan. Report binomial uncertainty; neither number is a power calculation for the live study. Bias MCSE is sd(error)/sqrt(R); MSE MCSE is sd(error²)/sqrt(R). The final 2,000-repetition validation sweep does not start under this document; the separately specified bounded development batch below is a preliminary implementation check, not that final study.

## 3. Substantive agent study: two decisions inside repository repair

**Selected harness:** pinned mini-swe-agent with the pinned SWE-bench evaluator. Reuse the environment, action loop and terminal tests; implement only the routing/logging adapter and the design-specific statistics. The [harness audit](literature_harness_design_20260921.md) gives exact source hooks and hazards. BrowserGym/AgentLab on qualified MiniWoB tasks is a fallback mechanism pilot, not a replacement claim about real repository repair. Router-R1 changes the coordinator and aggregation; reserve it for an explicitly different whole-system comparison.

**Treatment:** a model choice before logical call 1 and, if still active, before logical call 9. Retain that backend for calls 1–8 or 9–24, respectively. The same message history, repository state, prompts, parser, tool permissions, stopping and context limits apply to every policy. This creates at most two eligible decisions, not 24 independent treatments. Absorbed episodes stay in the denominator. The 8/24 configuration is a development candidate, not evidence that the horizon is adequate.

**Candidate executors:** pinned Qwen2.5-Coder-7B-Instruct and 14B-Instruct; their license/revision record is in the harness audit. Resource fit, serving compatibility and competence are untested here. Prefer a common 16,384-token context and 1,536-token response cap, with a frozen decoding/quantization convention; actual converted-weight digests and server versions must be recorded. If the available host cannot support this pair, revise the development configuration explicitly rather than silently substituting models or buying API capacity.

**Status of that historical candidate, 26 September:** subsequent DEVELOPMENT failures closed the local
7B/14B coding path. The proposed replacement pair remains blocked on the inspected host under REQ-020/021;
see the [current evidence map](experiment_results.md). The paragraph above records the original candidate,
not present qualification or authorization to rerun it.

**Feedback:** issue text, ordinary shell/tool outputs and the agent's earlier actions. A nonzero shell status is not automatically a unit-test failure. No checks means unverified, not success. Hidden terminal tests, reference patches and final grades cannot enter histories or trigger another opportunity. Preserve submission/timeout/format-limit exits. Require an explicit eligible submission: limits or format failures returning an empty submission score zero for the primary operational endpoint; do not silently extract and grade a different workspace patch. A later salvage rule would change the harness and must be declared separately.

**Prospective logging:** independent known 1/2 choices at each eligible decision conditional on recorded pre-action history; persist action, probability, draw, remaining budget and version before invocation. Offer the decision only if both backends meet the common pre-action token/request reservation rule; otherwise terminate. All target policies use this same eligibility rule. This avoids an unrecorded budget-forced action; any later single-feasible-action design needs probability 1 and corresponding target overrides explicitly specified. Hard elapsed-time limits can still interrupt execution and are recorded as exits. A deterministic supported target has a path ratio bounded by four for this two-decision logger. This is a weight bound, not a finite-sample precision guarantee. Physical transport retries keep the same assigned action; cap and log retries across all client/server layers. Never redraw the model on retry or invoke an unlogged fallback.

## 4. Comparators, training and sealed evaluation

Use all four stage schedules SS, SL, LS, LL during development; select the best fixed schedule using development data only and include SS/LL as interpretable references. Predeclare tie-breaking and the same budget eligibility rule.

The **primary history contrast** gives both candidate routers initial S. At decision 2, one can use only initial-task features; the other can additionally use realized feedback and remaining budget. Fit both with the same restricted learner class and objective, including constant actions. The proposed starting class is depth-two trees with a preregistered finite feature set and validation-selected complexity. It is a falsifiable probe of observable tailoring, not an assertion that shallow trees are optimal. Record action variability within stages: collapse to a fixed schedule is reported as such. A later richer learner is a new development comparison.

Include the published **RouteLLM local classifier as an initial-only transfer baseline**, choosing a model once for the entire trajectory. Use the pinned XLM-RoBERTa checkpoint and narrow Transformers adapter, not the API-dependent MF path. Preserve its softmax-label-0 score and score>=threshold decision. Calibrate the threshold on development data; report model-pair/domain transfer and possible pretraining contamination. Add a domain-trained initial-only router so a weak transferred baseline cannot establish superiority by itself. These are secondary comparisons, distinct from the primary matched-initial-action contrast.

Use disjoint TRAIN, development/calibration and CONFIRM issue identities; group near-duplicate/family variants. State whether claims concern new issues within named repositories or new repositories. A repository-generalization claim requires held-out repositories, not merely issue IDs. Existing MBPP/HumanEval CONFIRM observations are permanently excluded from new tuning/confirmation. Public benchmark exposure in pretraining remains a limitation.

Freeze the policy catalog, features, weights/thresholds, endpoint, task IDs, budgets, uncertainty method and contrast family before CONFIRM. Interleave policies and logging within task and execution period; record all source/execution blocks. Same seed integers do not imply a valid coupling. Use independent randomization/execution streams for logs and fresh policy references; propagate both uncertainties. No optional stopping based on an encouraging effect.

## 5. Endpoints, adequacy and resource gates

Primary outcome is **verified terminal resolution under the common execution/evaluation pipeline and budget**, with all assigned episodes in the denominator. An eligible submission with a valid resolved report scores one; other episodes score zero for this operational endpoint. Keep evaluator timeouts/missing reports separately labeled unknown algorithmic correctness, not observed hidden-test failure. Permit at most one evaluator retry on the identical patch under a common declared allowance; never regenerate a solution using grading feedback. Report the failure reasons and worst-case success bounds assigning unresolved evaluator cases either zero or one for the secondary algorithmic endpoint. Do not use complete-case exclusion. This pipeline estimand must also be used by logging and fresh-policy evaluation.

**Prospective grading clarification (21 September; before v2 collection):** require every declared FAIL_TO_PASS and PASS_TO_PASS test to be observed `PASSED`, with nonempty FAIL_TO_PASS and the existing explicit-empty-PASS_TO_PASS limitation. Required tests observed SKIPPED or XFAIL do not satisfy this strict verified-pass endpoint. Missing tests do not pass. Preserve the unmodified pinned upstream report/score alongside this separately versioned strict score, with disagreement reasons; this is a study-specific endpoint, not an interchangeable official SWE-bench score. Apply the same rule to logging and fresh-policy evaluation. After assignment, skipped/expected-failure outcomes do not justify dropping tasks. Before sampling, isolated no-change/reference-patch controls must qualify the exact task/image under this rule; failures require diagnosis and a documented, outcome-independent qualification decision. Evaluator failures or unparsable output remain zero for operational resolution and separately unknown for algorithmic correctness, with the existing retry and sensitivity rules. See the [M03 lead decision](theory_feedback_20260921_m03.md).

Report physical requests, small/large calls, input/output tokens, router overhead, setup/load time, inference time and total elapsed time separately. Match deterministic caps and show realized costs; equal large-call share is not equal compute. Claims of success improvement require an interval for the prespecified contrast; claims of resource saving with acceptable success require a prospectively chosen success-loss margin and a joint rule. Keep archived .01/.03 call penalties unchanged. Do not tune a new utility on CONFIRM. When the common two-action reservation rule fails, terminate as specified above.

**Infrastructure gate, later execution:** verify nonempty fail-to-pass sets, required-test mapping, a failing no-change control and a passing reference-patch control. Empty pass-to-pass sets require an explicit regression-coverage limitation. Qualify using evaluator validity, never model success. Bind each evaluation to task × policy × replicate × invocation and patch hash; existing cached reports must not substitute for new execution. Use disposable isolated workers with no project credentials.

**Development feasibility only:** after a small resource check, propose up to 20 qualified development issues × four schedules × one trajectory (80 total, at most 1,920 logical calls). Freeze a practical token/time allowance before this pilot; the worst-case output allowance is already 2.95 million returned tokens, or 5.90 million with two full physical attempts per call, before preprocessing/evaluation costs. It is not automatically cheap. No API key is needed in principle; measured local fit and throughput decide feasibility.

Report all denominators, second-decision occupancy, feedback variation, success/failure rates and infrastructure exits. Suggested redesign flags are zero successes across all schedules, >10% infrastructure failures, or <50% reaching decision 2. They are development flags, not significance tests or test-set exclusions. Do not require a favorable router effect. Failure may justify a new development configuration or a narrower paper.

**Precision gate:** the one-execution pilot cannot estimate all within-task execution variance. Obtain a separately budgeted repeated-execution development sample if needed; use its task/block covariance and uncertainty to choose the final number of tasks and replicates. Conditional on frozen trained policies and independent task execution blocks, a fixed nonidentical task mean has execution variance J^−2 sum_g Var(D_g), not iid sampling variance of task means. Shared execution-period effects require cross-task covariance terms or a justified block model. Require a reviewed design-specific interval/test, justified nuisance treatment and multiplicity control before final collection. Validate its operating characteristics in the matching simulator. Prespecify a scientifically useful gap/margin and target precision; the lead must record these numerical choices with the resource envelope before marking the plan frozen. They remain open rather than invented here.

## 6. Immediate worker deliverables, without new execution

1. Produce the corrected archived A6 report and an evidence/unknowns table for source blocks, fresh pairs and recovery assumptions. Accept only source-bound agreement with the lead's audits and preservation of all original outcomes. Apply the [conditional-frame correction](theory_feedback_20260921_conditional_frame.md); do not close primary B2 by changing its target.
2. Draft the mini-swe-agent and RouteLLM adapter interfaces against the pinned sources: histories, two assignment points, retry semantics, caps, IDs, terminal records and exact license/dependency inventory. Acceptance: a field/hook map and deterministic fixtures specified; no claims of installation or execution. Use upstream harness/evaluator code rather than rebuilding them.
3. Provide explicit finite simulation tables, frozen policy definitions, two exact-truth paths and an archive-matching block generator specification. Acceptance: the analytic controls above and target-invariance checks can be independently checked; list every unresolved inference assumption. The initial no-Monte-Carlo design phase is superseded for the experiment worker only by the bounded development batch below; the theory worker still launches none.

The lead will review these artifacts and select the numerical precision/resource plan. All commits use Yukang Zeng <ykzeng2019@gmail.com> as author and committer, direct main, no PRs. Design progress alone leaves full-project readiness at **55%, change 0 points, judgment range 45–65%**. Largest gaps: useful validated inference/adequate comparisons; remaining statistical validation and final empirical synthesis; independent reproducibility, author metadata and submission package.


## 7. Lead priority reset, 21 September 2026, 12:40 UTC

The author asked why repeated half-hour exchanges produced no new experimental results. Feedback was being
published and acknowledged, but the lead let repair cycles and an overbroad compute-deferral sentence obstruct
end-to-end scientific validation. This section corrects the work order, not the frozen primary targets.

**DTR-REQ-003, P0 next deliverable: one end-to-end CPU development results table.** The separately authorized
experiment worker should complete its existing runner/seeded draw source and run this bounded batch on its
existing CPU resources; no GPU, model calls, paid services or compute purchase. Freeze and commit the execution
manifest/code before the batch. Do not wait for SWE-bench/Docker permission, the secondary branch module, or
all DR/OR methods to be ready before reporting the initial IPW/fresh baseline.

- Existing common-first-small repair generator, K=2, crossing effects, informative and weak feedback; each
  with uniform-floor-.5 and feedback-dependent-floor-.2 logger: four existing design cells, no new cells.
- Existing fixed 250-task balanced list, four logged repetitions/task and four independent fresh repetitions
  per task/policy; policies: frozen history-large-after-exception, prompt-only-large-if-hard and the existing
  exact-table best fixed schedule (label this last comparator as known-kernel selected, not learned).
- Exactly 200 complete development repetitions/cell, root seed 2026092101 and stable independent namespaces
  for repetition/cell/role/policy/task/replicate. CPU wall-time cap 15 minutes for this first batch; if exhausted,
  publish the completed counts and resource limit, without extrapolating success or changing the batch based
  on outcomes. No branch execution or final confirmatory claim in this batch.
- Report exact truth, empirical bias with its Monte Carlo SE, RMSE, empirical sampling SD against the
  accepted exact SD, mean log-minus-fresh discrepancy with Monte Carlo SE, costs, complete/failed counts and
  seeds/source hashes. Publish unfavorable and partial results. This checks distributional wiring; it does
  not establish interval coverage, adaptation benefit or resource efficiency. A discrepancy unexplained by
  Monte Carlo uncertainty triggers a focused diagnosis, not extra runs to obtain agreement.
- Required before launch: existing transition/weight tests and complete-manifest regressions pass; no known
  defect affecting this batch's endpoint, assignment probabilities or denominators. Unrelated adapter
  hardening and the secondary branch study must not block this batch.

**Next scientific comparison after that baseline:** wire task-split DR/OR using the existing
`experiments/code_routing/estimators_absorbing.py` where compatible. Document observation/history mapping and
check absorption, target probabilities and task folds; do not leak latent U into fitted observed-history
features. Known-kernel Q is a separately labeled positive control. Preserve the final 2,000-repetition coverage
plan; learned nuisance fitting and actual intervals must be checked before any final coverage claim.

**DTR-REQ-002:** actual benchmark qualification remains open. At the next checkpoint, report the precise
external-host action blocked and the applicable permission rule/request status, separating passive public-file
retrieval from upstream code execution and system installation. The lead cannot waive another host's rules.
Do not hold the CPU simulation path for that blocker or repeat a vague request for general approval.

The 30-minute update is an exchange interval, not a work slice or an instruction to stop between checkpoints.
Continue authorized work across ticks. Each update must lead with a results artifact and counts, or an exact
blocking action and the independent work proceeding; test counts alone are implementation progress. The lead
owns the scientific acceptance and manuscript synthesis. Current readiness stays 55%, change 0 points, range
45–65%, until the evidence changes. Nothing here is an empirical result or submission authorization.
